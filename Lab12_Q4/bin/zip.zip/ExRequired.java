

public class ExRequired extends ExControll{

	public ExRequired(String e) {
		super(e);
	}
}
