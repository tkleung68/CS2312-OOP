
public class ExNotExist extends ExControll{

	public ExNotExist(String e) {
		super(e);
	}
}
