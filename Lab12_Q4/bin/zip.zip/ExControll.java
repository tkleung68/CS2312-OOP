
public class ExControll extends Exception{

	public ExControll(String e) {
		super(e);
	}
}
