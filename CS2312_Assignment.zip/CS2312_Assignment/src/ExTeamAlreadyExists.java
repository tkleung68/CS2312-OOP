
public class ExTeamAlreadyExists extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExTeamAlreadyExists() {
		super("Insufficient balance.");
	}
	
	public ExTeamAlreadyExists(String message) {
		super(message);
	}
}
