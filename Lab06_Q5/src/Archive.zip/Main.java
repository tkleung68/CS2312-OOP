

import java.util.*;
import java.io.*;

public class Main{

	public static void main(String [] args) throws FileNotFoundException
	{	
		Scanner in = new Scanner(System.in);
		
		System.out.print("Please input the file pathname: ");
		String str = in.nextLine();
		String filepathname;
		int temp1 = 0;
		int temp2 = 0;
		ArrayList<Team> t = new ArrayList<Team>();
		
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i) == '.') {
				
				temp2 = i + 4;
				filepathname = str.substring(temp1,temp2);
				t.add(new Team(filepathname));
				temp1 = i + 4;
			}
		}
		
		
		System.out.println("\nListing of teams");
		for(int i=0;i<t.size();i++) {
		System.out.printf(
			"[Team %d] %d members: %s\n", 
			i+1,t.get(i).getMemberCount(), t.get(i).getStringOfAllMembers()); //call Team methods to get the results: getMemberCount, getStringOfAllMembers
		 //call Team method: printTeamContactMessages
		}
		
		System.out.print("\nEnter a name for searching: ");
		String str2;
		str2 = in.next();
		boolean notfound = true;
		for(int i=0;i<t.size() && notfound;i++) {
			if(t.get(i).find(str2)) {
				System.out.printf("%s is %s in Team %d",str2,t.get(i).search(str2),i+1);
				notfound = false;
			}else if(i== t.size()-1 && !t.get(i).find(str2)) {
				System.out.print("Not found");
			}
		}
		
		
		in.close();
	}
}