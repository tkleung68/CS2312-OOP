import java.util.*;
import java.util.Collections;
public class Employee implements Comparable<Employee>{

	
	private String name;
	private int yrLeavesEntitled;
	private ArrayList<Day> takeLeaveList;
	
	public String getName() {
		return name;
	}
	
	public static Employee searchEmployee(ArrayList<Employee> list, String nameToSearch) {
		for(Employee e:list) {
			if(e.getName().equals(nameToSearch)) {
				return e;
			}
		}
		
		return null;
	}
	
	public Employee(String n, int yle) {
		name = n;
		yrLeavesEntitled = yle;
		takeLeaveList = new ArrayList<>();
	}
	
	@Override
	public int compareTo(Employee another) {
		if(this.name.equals(another.name)) return 0;		
		else if (this.name.compareTo(another.name)>0) return 1;
		else return -1;
	}
	
	public int getDay() {
		return yrLeavesEntitled;
	}
	
	public void takeLeave(Day start, Day end) throws ExOverlapLeave{
		for(int i=0;i<takeLeaveList.size();i=i+2) {
			if(start.isOverlapWithPeriod(end,takeLeaveList.get(i),takeLeaveList.get(i+1)))
				throw new ExOverlapLeave("Overlap with leave from " + takeLeaveList.get(i).toString() + " to " + takeLeaveList.get(i+1).toString() +"!");
		}
		takeLeaveList.add(start);
		takeLeaveList.add(end);
		yrLeavesEntitled = yrLeavesEntitled - start.countDay(end) - 1;
		Collections.sort(takeLeaveList);
	}
	
	public void removeLeave(Day start, Day end) {
		takeLeaveList.remove(end);
		takeLeaveList.remove(start);
		yrLeavesEntitled = yrLeavesEntitled + start.countDay(end) +1;
		
	}
	
	public void listLeavesTaken() {
		for(int i = 0;i < takeLeaveList.size();i = i+2) {
			System.out.printf("%s to %s\n", takeLeaveList.get(i).toString(),takeLeaveList.get(i+1).toString());
		}
	}
	
	public int getLeavesTakan() {
		return takeLeaveList.size()/2;
	}
	
	
	
}
