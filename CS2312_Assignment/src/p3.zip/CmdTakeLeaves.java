

public class CmdTakeLeaves extends RecordedCommand{
	Employee employee;
	Day start;
	Day end;
	
	@Override
	public void execute(String[] cmdParts)
	{
		
		try {
			if(cmdParts.length<3)
				throw new ExInsufficientArguments();
			
			Company company = Company.getInstance();
			employee = company.searchEmployee(cmdParts[1]);
			
			start = new Day(cmdParts[2]);
			end = new Day(cmdParts[3]);
			
			if(start.countDay(end) > employee.getDay())
				throw new ExInsufficientBalance();
			
			
			if(start.compareTo(SystemDate.getInstance()) == -1 || end.compareTo(SystemDate.getInstance()) == -1)
				throw new ExWrongDate();
			
			employee.takeLeave(start, end);
			addUndoCommand(this);
			clearRedoList();
			System.out.println("Done.");
			
		} catch(ExInsufficientArguments e) {
			System.out.println(e.getMessage());
		} catch(ExWrongDate e) {
			System.out.printf("Wrong Date.   System date is already %s!\n",SystemDate.getInstance().toString());
		} catch(ExInsufficientBalance e) {
			System.out.printf("Insufficient balance.  %d days left only!\n", employee.getDay());
		} catch(ExOverlapLeave e) {
			System.out.println(e.getMessage());
		} catch (ExEmployeeNotFound e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public void undoMe()
	{
		employee.removeLeave(start, end);
		addRedoCommand(this); 
	}
	
	@Override
	public void redoMe()
	{
		try {
			employee.takeLeave(start, end);
			addUndoCommand(this);
		} catch (ExOverlapLeave e) {
			System.out.println(e.getMessage());
		} 
	}
}
