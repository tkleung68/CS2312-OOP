import java.util.*;

public class Team implements Comparable<Team>{
	
	private String teamName;
	private Employee head;
	private Day dateSetup;
	private ArrayList<Employee> allTeammates;

public Team(String n, Employee hd) {
	head = hd;
	teamName = n;
	dateSetup = SystemDate.getInstance().clone();
	allTeammates = new ArrayList<>();
	allTeammates.add(head);
}

public String getTeamName() {
	return teamName;
}

public String getName() {
	return head.getName();
}


public static Team searchTeamByTeamName(ArrayList<Team> list, String teamName) {
	for(Team t:list) {
		if(t.getTeamName().equals(teamName)) {
			return t;
		}
	}
	return null;
}

public static void list (ArrayList<Team> list) {

	System.out.printf("%-30s%-10s%-13s\n", "Team Name", "Leader" , "Setup Date");
	for (Team t : list)
		System.out.printf("%-30s%-10s%-13s\n",t.teamName,t.head.getName(),t.dateSetup.toString()); //display t.teamName, etc..
}

@Override
public int compareTo(Team o) {
	return this.teamName.compareTo(o.teamName);
}

public void addTeamMember (Employee e) {
	allTeammates.add(e);
	Collections.sort(allTeammates);
}

public void deleteTeamMember(Employee e) {
	allTeammates.remove(e);
}

public boolean searchTeammates(Employee e) {
	if(e.equals(head)) {
		return true;
	}
	for(Employee employee: allTeammates) {
		if(employee.equals(e)) {
			return true;
		}
	}
	return false;
}

public void listRole(Employee e) {

	for(Employee employee: allTeammates) {
		if(employee.equals(e)) {
			if(e.equals(head)) {
				System.out.println((teamName +  " (Head of Team)")); 
			}else {
				System.out.println(teamName);
			}
		}
	}
}

public void printTeamInfo() {
	System.out.println(teamName + ":");
	
	for(Employee e:allTeammates) {
		if(e.getName().equals(head.getName())) {
			System.out.println((head.getName() +  " (Head of Team)"));
		}else {
			System.out.println(e.getName());
		}
	}
	System.out.println();
}		
}
